import React, { useState } from 'react';
import { DotsThree, MagnifyingGlass, FunnelSimple, CaretLeft, CaretRight } from '@phosphor-icons/react';
import './tableContent.css';

const TableManagement = () => {
  const [tables] = useState([
    { id: 1, hour: '12:30 PM', space: 'Indoor', user: 'John Doe', price: 45.00 },
    { id: 2, hour: '01:15 PM', space: 'Outdoor', user: 'Jane Smith', price: 35.50 },
    { id: 3, hour: '02:45 PM', space: 'Indoor', user: 'Mike Johnson', price: 50.00 },
    { id: 4, hour: '03:30 PM', space: 'Outdoor', user: 'Sarah Williams', price: 40.00 },
    { id: 5, hour: '04:00 PM', space: 'Indoor', user: 'David Brown', price: 55.75 },
    { id: 6, hour: '05:15 PM', space: 'Outdoor', user: 'Emma Wilson', price: 42.00 },
    { id: 7, hour: '06:30 PM', space: 'Indoor', user: 'James Taylor', price: 60.25 },
    { id: 8, hour: '07:45 PM', space: 'Outdoor', user: 'Olivia Brown', price: 38.50 },
    { id: 9, hour: '08:00 PM', space: 'Indoor', user: 'William Clark', price: 52.75 },
    { id: 10, hour: '09:15 PM', space: 'Outdoor', user: 'Sophia Martinez', price: 45.00 },
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState('All');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  const stats = [
    { value: '2445 DT', description: 'Total revenue' },
    { value: '2', description: 'Tables currently occupied' },
    { value: '12', description: 'Recent changes' }
  ];

  const filterOptions = [
    { value: 'All', label: 'All' },
    { value: 'Indoor', label: 'Indoor' },
    { value: 'Outdoor', label: 'Outdoor' }
  ];

  const handleActionClick = (tableId, action) => {
    console.log(`Action ${action} clicked for table ${tableId}`);
  };

  const handleFilterSelect = (filter) => {
    setSelectedFilter(filter);
    setIsFilterOpen(false);
    setCurrentPage(1);
  };

  const filteredTables = tables.filter(table => {
    const matchesSearch = 
      table.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      table.space.toLowerCase().includes(searchQuery.toLowerCase()) ||
      table.hour.toLowerCase().includes(searchQuery.toLowerCase()) ||
      table.id.toString().includes(searchQuery);
    
    const matchesSpace = selectedFilter === 'All' || table.space === selectedFilter;
    
    return matchesSearch && matchesSpace;
  });

  const totalPages = Math.ceil(filteredTables.length / itemsPerPage);
  const currentTables = filteredTables.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handlePageChange = (newPage) => {
    setCurrentPage(newPage);
  };

  return (
    <div className="table-mgmt-container">
      <div className="table-mgmt-header">
        <h2>Table Details</h2>
      </div>

      <div className="table-mgmt-stats-cards">
        {stats.map((stat, index) => (
          <div key={index} className="table-mgmt-stat-card">
            <div className="table-mgmt-stat-value">{stat.value}</div>
            <div className="table-mgmt-stat-description">{stat.description}</div>
          </div>
        ))}
      </div>

      <div className="table-mgmt-controls">
        <div className="table-mgmt-search-box">
          <MagnifyingGlass weight="bold" className="table-mgmt-search-icon" />
          <input
            type="text"
            placeholder="Search tables..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="table-mgmt-filter-dropdown">
          <button className="table-mgmt-filter-btn" onClick={() => setIsFilterOpen(!isFilterOpen)}>
            <FunnelSimple weight="bold" />
            Filter
          </button>
          {isFilterOpen && (
            <div className="table-mgmt-filter-menu">
              {filterOptions.map((option) => (
                <div 
                  key={option.value}
                  className={`table-mgmt-filter-option ${selectedFilter === option.value ? 'selected' : ''}`}
                  onClick={() => handleFilterSelect(option.value)}
                >
                  {selectedFilter === option.value && (
                    <span className="table-mgmt-check">✓</span>
                  )}
                  {option.label}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="table-mgmt-list-container">
        <table className="table-mgmt-table">
          <thead>
            <tr>
              <th>Table</th>
              <th>Hour</th>
              <th>Space</th>
              <th>User</th>
              <th>Price</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {currentTables.map(table => (
              <tr key={table.id}>
                <td>#{table.id}</td>
                <td>{table.hour}</td>
                <td>{table.space}</td>
                <td>{table.user}</td>
                <td>{table.price.toFixed(2)} DT</td>
                <td>
                  <div className="table-mgmt-actions">
                    <button 
                      className="table-mgmt-action-btn"
                      onClick={() => handleActionClick(table.id, 'menu')}
                    >
                      <DotsThree size={20} weight="bold" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="table-mgmt-pagination">
          <button 
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="table-mgmt-pagination-btn"
          >
            <CaretLeft size={18} weight="bold" />
          </button>
          
          <div className="table-mgmt-page-indicator">
            Page {currentPage} of {totalPages}
          </div>
          
          <button 
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="table-mgmt-pagination-btn"
          >
            <CaretRight size={18} weight="bold" />
          </button>
        </div>
      )}
    </div>
  );
};

export default TableManagement;