import React, { useState } from 'react';
import { DotsThree, MagnifyingGlass, FunnelSimple, CaretLeft, CaretRight, ChatCircleDots } from '@phosphor-icons/react';
import "./cashDrawerContent.css"

const CashDrawerContent = () => {
  const [transactions] = useState([
    { id: 1, hour: '09:30 AM', user: 'John Doe', operation: 'Sale', description: 'Table #5', amount: 45.00, },
    { id: 2, hour: '10:15 AM', user: 'Jane Smith', operation: 'Refund', description: 'Order #142', amount: -15.50,  },
    { id: 3, hour: '11:45 AM', user: 'Mike Johnson', operation: 'Sale', description: 'Table #8', amount: 60.00,  },
    { id: 4, hour: '12:30 PM', user: 'Sarah Williams', operation: 'Expense', description: 'Supplies', amount: -25.00,  },
    { id: 5, hour: '02:00 PM', user: 'David Brown', operation: 'Sale', description: 'Table #3', amount: 55.75,  },
    { id: 6, hour: '03:15 PM', user: 'Emma Wilson', operation: 'Sale', description: 'Table #7', amount: 42.00,  },
    { id: 7, hour: '04:30 PM', user: 'James Taylor', operation: 'Sale', description: 'Table #1', amount: 38.50,},
    { id: 8, hour: '05:45 PM', user: 'Olivia Brown', operation: 'Sale', description: 'Table #2', amount: 72.25,  },
    { id: 9, hour: '07:00 PM', user: 'William Clark', operation: 'Withdrawal', description: 'Owner', amount: -100.00,  },
    { id: 10, hour: '08:15 PM', user: 'Sophia Martinez', operation: 'Sale', description: 'Table #4', amount: 65.00,  },
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState('All');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  const stats = [
    { value: '2445 DT', description: 'Total collected' },
    { value: '1200 DT', description: 'Cash' },
    { value: '845 DT', description: 'Credit Card' },
    { value: '400 DT', description: 'Restaurant tickets' }
  ];

  const filterOptions = [
    { value: 'All', label: 'All' },
    { value: 'Sale', label: 'Sales' },
    { value: 'Refund', label: 'Refunds' },
    { value: 'Expense', label: 'Expenses' },
    { value: 'Withdrawal', label: 'Withdrawals' }
  ];

  const handleFilterSelect = (filter) => {
    setSelectedFilter(filter);
    setIsFilterOpen(false);
    setCurrentPage(1);
  };

  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = 
      transaction.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.operation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.id.toString().includes(searchQuery);
    
    const matchesOperation = selectedFilter === 'All' || transaction.operation === selectedFilter;
    
    return matchesSearch && matchesOperation;
  });

  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);
  const currentTransactions = filteredTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handlePageChange = (newPage) => {
    setCurrentPage(newPage);
  };

  return (
    <div className="cd-cashdrawer-container">
      <div className="cd-cashdrawer-header">
        <h2>Cash Drawer</h2>
      </div>

      <div className="cd-stats-cards">
        {stats.map((stat, index) => (
          <div key={index} className="cd-stat-card">
            <div className="cd-stat-value">{stat.value}</div>
            <div className="cd-stat-description">{stat.description}</div>
          </div>
        ))}
      </div>

      <div className="cashdrawer-controls flex mb-10 justify-between">
        <div className="cd-search-box">
          <MagnifyingGlass weight="bold" className="cd-search-icon" />
          <input
            type="text"
            placeholder="Search transactions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="cd-filter-dropdown">
          <button className="cd-filter-btn" onClick={() => setIsFilterOpen(!isFilterOpen)}>
            <FunnelSimple weight="bold" />
            Filter
          </button>
          {isFilterOpen && (
            <div className="cd-filter-menu">
              {filterOptions.map((option) => (
                <div 
                  key={option.value}
                  className={`cd-filter-option ${selectedFilter === option.value ? 'selected' : ''}`}
                  onClick={() => handleFilterSelect(option.value)}
                >
                  {selectedFilter === option.value && (
                    <span className="cd-check">✓</span>
                  )}
                  {option.label}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="cd-cashdrawer-list-container">
        <table className="cd-data-table">
          <thead>
            <tr>
              <th>Hour</th>
              <th>User</th>
              <th>Operation</th>
              <th>Description</th>
              <th>Amount</th>
              <th>Comment</th>
            </tr>
          </thead>
          <tbody>
            {currentTransactions.map(transaction => (
              <tr key={transaction.id}>
                <td>{transaction.hour}</td>
                <td>{transaction.user}</td>
                <td>{transaction.operation}</td>
                <td>{transaction.description}</td>
                <td style={{ color: transaction.amount >= 0 ? 'green' : 'red' }}>
                  {transaction.amount >= 0 ? '+' : ''}{transaction.amount.toFixed(2)} DT
                </td>
                <td>
                  <div className="cd-comment-cell">
                    <ChatCircleDots size={20} color="green" weight="fill" />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="cd-pagination">
          <button 
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="cd-pagination-btn"
          >
            <CaretLeft size={18} weight="bold" />
          </button>
          
          <div className="cd-page-indicator">
            Page {currentPage} of {totalPages}
          </div>
          
          <button 
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="cd-pagination-btn"
          >
            <CaretRight size={18} weight="bold" />
          </button>
        </div>
      )}
    </div>
  );
};

export default CashDrawerContent;